export interface metricsInterface {
  totalQuizzes: number;
  totalParticipants: number;
  activeSessions: number;
  sessionCompletionRate: DoubleRange;
}